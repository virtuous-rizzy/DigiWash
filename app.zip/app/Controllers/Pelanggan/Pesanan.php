<?php

namespace App\Controllers\Pelanggan;

use App\Controllers\BaseController;

class Pesanan extends BaseController
{
    /**
     * Daftar metode pembayaran yang sah + tujuan transfernya.
     * Dipakai untuk validasi (whitelist) dan ditampilkan di halaman upload bukti.
     * Nanti pindahkan ke tabel (mis. `metode_pembayaran`) supaya admin bisa mengubahnya.
     */
    private const REKENING = [
        'Bank BCA'     => '1234-5678-9012',
        'Bank BRI'     => '0987-6543-2101',
        'Bank BNI'     => '1122-3344-5566',
        'Bank Mandiri' => '9988-7766-5544',
        'DANA'         => '0812-xxxx-xxxx',
        'GoPay'        => '0821-xxxx-xxxx',
        'ShopeePay'    => '0856-xxxx-xxxx',
    ];

    private const DIR_BUKTI = 'uploads/bukti';

    public function pilihLayanan()
    {
        return view('Pesanan/pilih_layanan');
    }

    public function buatPesanan()
    {
        $jenisLayanan = $this->request->getGet('layanan') ?? 'Reguler';

        // Jika POST (setelah ubah alamat), ambil layanan dari POST
        if ($this->request->getMethod() === 'post') {
            $jenisLayanan = $this->request->getPost('layanan') ?? $jenisLayanan;
        }

        // Tentukan harga & konfigurasi berdasarkan jenis layanan
        $hargaPerKg = 7000;
        if ($jenisLayanan === 'Express') {
            $hargaPerKg = 12000;
        } elseif ($jenisLayanan === 'BedCover') {
            $hargaPerKg = 7000;
        }

        $data = [
            'layanan'     => $jenisLayanan,
            'harga_per_kg' => $hargaPerKg,
            'alamat'      => 'Jl. Melati No. 12, RT 02/RW 01, Kec. Sukmajaya Depok',
            'tanggal'     => '5 Juni 2026',
        ];

        return view('Pesanan/buat_pesanan', $data);
    }

    public function ringkasan()
    {
        $data = [
            'id_pesanan'    => 'PSN-' . date('Ymd') . '-001',
            'layanan'       => $this->request->getPost('layanan'),
            'berat'         => $this->request->getPost('berat'),
            'total'         => $this->request->getPost('total_harga'),
            'alamat'        => $this->request->getPost('alamat'),
            'tanggal'       => $this->request->getPost('tanggal_penjemputan'),
            'catatan'       => $this->request->getPost('catatan'),
            'detail_satuan' => $this->request->getPost('detail_satuan'),
        ];

        return view('Pesanan/ringkasan', $data);
    }

    public function konfirmasiPesanan()
    {
        // Terima data dari form ringkasan, teruskan ke pembayaran via session
        $session = session();

        // Pesanan baru → bukti & metode dari pesanan sebelumnya tidak boleh terbawa
        $this->hapusBuktiTersimpan();
        $session->remove('pesanan_metode_bayar');

        $session->set([
            'pesanan_id_pesanan'    => $this->request->getPost('id_pesanan'),
            'pesanan_layanan'       => $this->request->getPost('layanan'),
            'pesanan_berat'         => $this->request->getPost('berat'),
            'pesanan_total'         => $this->request->getPost('total'),
            'pesanan_alamat'        => $this->request->getPost('alamat'),
            'pesanan_tanggal'       => $this->request->getPost('tanggal'),
            'pesanan_catatan'       => $this->request->getPost('catatan'),
            'pesanan_detail_satuan' => $this->request->getPost('detail_satuan'),
        ]);

        return redirect()->to(base_url('pesanan/pembayaran'));
    }

    public function pembayaran()
    {
        $session = session();
        $data = [
            'id_pesanan' => $session->get('pesanan_id_pesanan') ?? ('PSN-' . date('Ymd') . '-001'),
            'total'      => $session->get('pesanan_total') ?? 0,
            'layanan'    => $session->get('pesanan_layanan') ?? '-',
        ];
        return view('Pesanan/pembayaran', $data);
    }

    /**
     * Langkah 1: pelanggan memilih metode → lanjut ke halaman upload bukti
     * (BUKAN langsung ke status pembayaran).
     */
    public function prosesPembayaran()
    {
        $session = session();
        $metode  = (string) $this->request->getPost('metode_bayar');

        // Whitelist: nilai dari form tidak boleh dipercaya begitu saja
        if (! array_key_exists($metode, self::REKENING)) {
            return redirect()->to(base_url('pesanan/pembayaran'))
                ->with('errors', ['Pilih metode pembayaran yang tersedia.']);
        }

        // Ganti metode = bukti lama tidak relevan lagi
        if ($metode !== (string) $session->get('pesanan_metode_bayar')) {
            $this->hapusBuktiTersimpan();
        }

        $session->set('pesanan_metode_bayar', $metode);

        return redirect()->to(base_url('pesanan/upload-bukti'));
    }

    /**
     * Langkah 2 (GET): halaman upload bukti pembayaran.
     */
    public function uploadBukti()
    {
        $session = session();

        if ($session->get('pesanan_total') === null) {
            return redirect()->to(base_url('pesanan/pilih-layanan'));
        }

        $metode = (string) $session->get('pesanan_metode_bayar');
        if (! array_key_exists($metode, self::REKENING)) {
            return redirect()->to(base_url('pesanan/pembayaran'));
        }

        $data = [
            'id_pesanan' => $session->get('pesanan_id_pesanan') ?? ('PSN-' . date('Ymd') . '-001'),
            'layanan'    => $session->get('pesanan_layanan') ?? '-',
            'metode'     => $metode,
            'rekening'   => self::REKENING[$metode],
            'total'      => (int) $session->get('pesanan_total'),
            'bukti_url'  => $this->urlBukti(),
        ];

        return view('Pesanan/upload_bukti', $data);
    }

    /**
     * Langkah 2 (POST): simpan file bukti, lalu lanjut ke status pembayaran.
     */
    public function simpanBukti()
    {
        $session = session();

        if ($session->get('pesanan_total') === null) {
            return redirect()->to(base_url('pesanan/pilih-layanan'));
        }
        if (! array_key_exists((string) $session->get('pesanan_metode_bayar'), self::REKENING)) {
            return redirect()->to(base_url('pesanan/pembayaran'));
        }

        $rules = [
            'bukti' => [
                'label'  => 'Bukti pembayaran',
                'rules'  => 'uploaded[bukti]|is_image[bukti]|mime_in[bukti,image/jpg,image/jpeg,image/png,image/webp]|max_size[bukti,2048]',
                'errors' => [
                    'uploaded' => 'Pilih foto bukti pembayaran terlebih dahulu.',
                    'is_image' => 'File harus berupa gambar.',
                    'mime_in'  => 'Format file harus JPG, PNG, atau WEBP.',
                    'max_size' => 'Ukuran file maksimal 2 MB.',
                ],
            ],
        ];

        if (! $this->validate($rules)) {
            return redirect()->to(base_url('pesanan/upload-bukti'))
                ->with('errors', $this->validator->getErrors());
        }

        $dir = FCPATH . self::DIR_BUKTI;
        if (! is_dir($dir)) {
            mkdir($dir, 0775, true);
        }

        $file = $this->request->getFile('bukti');
        $nama = $file->getRandomName();
        $file->move($dir, $nama);

        // Upload ulang → hapus file lama supaya tidak numpuk
        $this->hapusBuktiTersimpan();
        $session->set('pesanan_bukti', $nama);

        return redirect()->to(base_url('pesanan/status-pembayaran'));
    }

    /**
     * Halaman status hanya bisa dibuka setelah bukti diunggah.
     */
    public function statusPembayaran()
    {
        $session = session();

        if ($session->get('pesanan_total') === null) {
            return redirect()->to(base_url('pesanan/pilih-layanan'));
        }
        if (! array_key_exists((string) $session->get('pesanan_metode_bayar'), self::REKENING)) {
            return redirect()->to(base_url('pesanan/pembayaran'));
        }

        $buktiUrl = $this->urlBukti();
        if ($buktiUrl === null) {
            return redirect()->to(base_url('pesanan/upload-bukti'))
                ->with('errors', ['Unggah bukti pembayaran dulu sebelum melihat status.']);
        }

        $data = [
            'id_pembayaran' => 'PAY-' . date('dmY') . '-001',
            'id_pesanan'    => $session->get('pesanan_id_pesanan') ?? ('PSN-' . date('Ymd') . '-001'),
            'metode'        => $session->get('pesanan_metode_bayar'),
            'total'         => $session->get('pesanan_total') ?? 0,
            'bukti_url'     => $buktiUrl,
        ];
        return view('Pesanan/status_pembayaran', $data);
    }

    public function tracking()
    {
        $session = session();
        $data = [
            'id_pesanan' => $session->get('pesanan_id_pesanan') ?? ('PSN-' . date('Ymd') . '-001'),
            'layanan'    => $session->get('pesanan_layanan') ?? 'Reguler',
        ];
        return view('Pesanan/tracking', $data);
    }

    /* ── Helper bukti pembayaran ─────────────────────────────── */

    /** URL bukti yang sudah diunggah, atau null kalau belum ada / filenya hilang. */
    private function urlBukti(): ?string
    {
        $nama = (string) session()->get('pesanan_bukti');

        if ($nama === '' || ! is_file(FCPATH . self::DIR_BUKTI . '/' . $nama)) {
            return null;
        }

        return base_url(self::DIR_BUKTI . '/' . $nama);
    }

    /** Hapus file bukti yang tercatat di session (kalau ada) lalu bersihkan session-nya. */
    private function hapusBuktiTersimpan(): void
    {
        $nama = (string) session()->get('pesanan_bukti');

        if ($nama !== '') {
            // basename() menjaga agar nilai session tidak bisa dipakai keluar dari folder bukti
            $path = FCPATH . self::DIR_BUKTI . '/' . basename($nama);
            if (is_file($path)) {
                @unlink($path);
            }
        }

        session()->remove('pesanan_bukti');
    }
}